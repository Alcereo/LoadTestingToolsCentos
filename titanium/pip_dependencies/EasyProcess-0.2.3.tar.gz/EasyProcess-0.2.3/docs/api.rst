API
===

.. automodule:: easyprocess
        :members:
