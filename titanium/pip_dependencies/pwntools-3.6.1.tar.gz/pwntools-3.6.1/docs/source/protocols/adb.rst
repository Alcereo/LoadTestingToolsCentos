.. testsetup:: *

   from pwn import *
   from pwnlib.protocols.adb import AdbClient

:mod:`pwnlib.protocols.adb` --- ADB Protocol Implementation
===========================================================

.. automodule:: pwnlib.protocols.adb
   :members:
