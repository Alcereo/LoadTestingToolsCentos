.. testsetup:: *

   from pwnlib.util.cyclic import *


:mod:`pwnlib.util.cyclic` --- Generation of unique sequences
============================================================

.. automodule:: pwnlib.util.cyclic
   :members:
