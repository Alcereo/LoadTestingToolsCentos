.. testsetup:: *

    from pwn import *
    from pwnlib.util.fiddling import *


:mod:`pwnlib.util.fiddling` --- Utilities bit fiddling
======================================================

.. automodule:: pwnlib.util.fiddling
   :members:
