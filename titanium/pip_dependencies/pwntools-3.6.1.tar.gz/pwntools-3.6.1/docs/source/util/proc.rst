.. testsetup:: *

   from pwnlib.util.proc import *
   import os, sys


:mod:`pwnlib.util.proc` --- Working with ``/proc/``
===================================================

.. automodule:: pwnlib.util.proc
   :members:
