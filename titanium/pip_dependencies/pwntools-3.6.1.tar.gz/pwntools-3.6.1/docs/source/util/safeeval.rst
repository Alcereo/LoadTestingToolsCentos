.. testsetup:: *

   from pwnlib.util.safeeval import *
   _get_opcodes = pwnlib.util.safeeval._get_opcodes


:mod:`pwnlib.util.safeeval` --- Safe evaluation of python code
==============================================================

.. automodule:: pwnlib.util.safeeval
   :members:
