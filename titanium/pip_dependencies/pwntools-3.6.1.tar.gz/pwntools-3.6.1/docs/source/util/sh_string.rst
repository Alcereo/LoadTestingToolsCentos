.. testsetup:: *

   from pwn import *
   test = pwnlib.util.sh_string.test

:mod:`pwnlib.util.sh_string` --- Shell Expansion is Hard
===============================================================

.. automodule:: pwnlib.util.sh_string
   :members:
