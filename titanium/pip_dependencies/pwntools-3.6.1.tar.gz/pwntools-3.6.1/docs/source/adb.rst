.. testsetup:: *

   from pwn import *
   adb = pwnlib.adb

:mod:`pwnlib.adb` --- Android Debug Bridge
=====================================================

.. automodule:: pwnlib.adb.adb
   :members:

.. automodule:: pwnlib.adb.protocol
   :members:
