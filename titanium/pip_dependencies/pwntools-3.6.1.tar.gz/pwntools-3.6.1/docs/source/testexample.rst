.. testsetup:: *

   import os
   from pwnlib.testexample import add

:mod:`pwnlib.testexample` --- Example Test Module
==================================================

.. automodule:: pwnlib.testexample
   :members:
