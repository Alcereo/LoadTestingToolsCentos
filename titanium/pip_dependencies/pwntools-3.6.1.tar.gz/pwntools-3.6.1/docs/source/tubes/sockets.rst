.. testsetup:: *

   from pwn import *

:mod:`pwnlib.tubes.sock` --- Sockets
===========================================================


.. automodule:: pwnlib.tubes.sock

   .. autoclass:: pwnlib.tubes.sock.sock()
      :show-inheritance:


.. automodule:: pwnlib.tubes.remote

   .. autoclass:: pwnlib.tubes.remote.remote
      :members:
      :show-inheritance:

.. automodule:: pwnlib.tubes.listen

   .. autoclass:: pwnlib.tubes.listen.listen
      :members:
      :show-inheritance:
