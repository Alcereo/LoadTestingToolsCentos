.. testsetup:: *

   from pwn import *

:mod:`pwnlib.rop` --- Return Oriented Programming
=================================================

Submodules
----------

.. toctree::
   :glob:

   rop/*
