.. testsetup:: *

   from pwn import *

:mod:`pwnlib.rop.srop` --- Sigreturn Oriented Programming
==========================================================

.. automodule:: pwnlib.rop.srop
   :members:
