.. testsetup:: *

   from pwn import *

:mod:`pwnlib.elf.corefile` --- Core Files
===========================================================

.. automodule:: pwnlib.elf.corefile

  .. autoclass:: pwnlib.elf.corefile.Corefile
     :members:
     :show-inheritance:

  .. autoclass:: pwnlib.elf.corefile.Mapping
     :members:
