.. testsetup:: *

   from pwn import *
   from pwnlib.elf.config import parse_kconfig

:mod:`pwnlib.elf.config` --- Kernel Config Parsing
===========================================================

.. automodule:: pwnlib.elf.config
  :members:
