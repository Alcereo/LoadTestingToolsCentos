:mod:`pwnlib.atexit` --- Replacement for atexit
===============================================

.. automodule:: pwnlib.atexit
   :members:
