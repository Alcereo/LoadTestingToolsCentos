from __future__ import absolute_import

from pwnlib.flag.flag import submit_flag

__all__ = [
    'submit_flag',
]
