'''
Package contains all tank tool core code
'''
from .tankcore import TankCore  # noqa:F401
