class MavenReader(object):
    def close(self):
        pass

    def __iter__(self):
        yield None


class MavenStatsReader(object):
    def close(self):
        pass

    def __iter__(self):
        yield None
