class AndroidReader(object):
    def close(self):
        pass

    def __iter__(self):
        yield None


class AndroidStatsReader(object):
    def close(self):
        pass

    def __iter__(self):
        yield None
