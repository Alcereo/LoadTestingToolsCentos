'''
Agent to be installed at remote server
'''
